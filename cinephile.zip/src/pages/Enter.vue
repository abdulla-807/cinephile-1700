<template>
    <main class="main">
        <EnterUser/>
    </main>
</template>

<script setup>
import EnterUser from '../components/Enter/EnterUser.vue';
</script>

<style lang="scss">

</style>