<template>
    <main class="main">
        <Single type="movie"/>
    </main>
</template>

<script setup>
import Single from '../components/Single/Single.vue';
</script>

<style lang="scss">

</style>