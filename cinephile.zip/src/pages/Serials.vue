<template>
    <main class="main">
        <ListContent type="tv"/>
    </main>
</template>

<script setup>
import ListContent from '../components/ListContent/ListContent.vue';

</script>

<style lang="scss">

</style>