<template>
    <main class="main">
        <ListContent type="movie"/>
    </main>
</template>

<script setup>
import ListContent from '../components/ListContent/ListContent.vue';

</script>

<style lang="scss">

</style>