<template>
    <main class="main">
        <Search/>
    </main>
</template>

<script setup>
import Search from '../components/Search/Search.vue';
</script>

<style lang="scss">

</style>