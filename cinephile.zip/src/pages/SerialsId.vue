<template>
    <main class="main">
        <Single type="tv"/>
    </main>
</template>

<script setup>
import Single from '../components/Single/Single.vue';
</script>

<style lang="scss">

</style>