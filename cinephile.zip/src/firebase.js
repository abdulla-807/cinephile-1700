// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAxc5CbZUZgdUS6dBKkTBhkhP_OfXD0Yrw",
  authDomain: "cinephile-1700.firebaseapp.com",
  projectId: "cinephile-1700",
  storageBucket: "cinephile-1700.appspot.com",
  messagingSenderId: "1026474690946",
  appId: "1:1026474690946:web:670548c4505583a61c679b"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;