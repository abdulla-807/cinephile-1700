<template>
    <router-link to="/" class="more">
        <font-awesome-icon :icon="['fas', 'play']" class="more__icon"/>
        Смотерть трейлер
    </router-link>
</template>

<script setup>

</script>

<style lang="scss">

</style>